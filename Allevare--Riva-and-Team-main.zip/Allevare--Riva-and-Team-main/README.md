# Allevare--Riva-and-Team
This is a program I've done with two other members, We created the program from scratch using JSON, XML, CSS,HTML and connected it using SQL
This is a Web-Development project given by our lecturer and we did the entire thing under a week and a half
